function Rxy_new = RotMat_node(Rxy,DRxy)
Rxy_new = zeros(size(Rxy));
for i = 1:size(DRxy,2)
    Rxy_i = Rxy(:,i);
    DRxy_i = DRxy(:,i);
    R_oldi = expm(skew(Rxy_i));
    R = expm(skew(DRxy_i));
    R_newi = R*R_oldi;
    Rxy_newi = invskew(logm(R_newi));
    Rxy_new(:,i) = Rxy_newi;
end
end