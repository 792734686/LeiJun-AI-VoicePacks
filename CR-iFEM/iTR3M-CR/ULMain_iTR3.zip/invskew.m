function invskewA = invskew(A)
invskewA = [A(3,2),A(1,3),A(2,1)]';
end