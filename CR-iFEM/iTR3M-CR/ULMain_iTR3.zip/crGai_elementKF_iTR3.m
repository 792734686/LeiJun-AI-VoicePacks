function [EK_cr,EF_cr] = crGai_elementKF_iTR3(ENC,Eepi,we,wk,wg,t,Rxy,Thetaxy,Nuxy)
%%
% 计算A、G、P等
% 计算切线刚度阵（转动在结点坐标系）
[Te,enc] = transmat_iTR3(ENC);
ek = estiffmG_iTR3(enc,we,wk,wg,t);
% ef = eforcem_iTR3(enc0,Eepi,we,wk,wg,t);
Rr = Te(1:3,1:3);
Rr = Rr';
Npxy = Rr'*Nuxy;
ELEMu = Umat_to_lin([Npxy;Thetaxy']');
ef = ek*ELEMu;
r1e = [enc(1,:),0]';
r2e = [enc(2,:),0]';
r3e = [enc(3,:),0]';
x21 = r2e(1);
x31 = r3e(1);
x32 = r3e(2);
r1e_skew = skew(r1e);
r2e_skew = skew(r2e);
r3e_skew = skew(r3e);
G1 = [0,0,0;
      0,0,-1/x21;
      (x31-x21)/(x32*x21),1/x21,0;
      zeros(3,3)];
G2 = [0,0,0;
      0,0,1/x21;
      -x31/(x32*x21),-1/x21,0;
      zeros(3,3)];
G3 = [0,0,0;
      0,0,0;
      -1/x32,0,0;
      zeros(3,3)];
G = [G1',G2',G3']';
A1 = [-r1e_skew;eye(3)];
A2 = [-r2e_skew;eye(3)];
A3 = [-r3e_skew;eye(3)];
delta = eye(3,3);
% ------------------------------
% 计算P、E
P11 = eye(6)*delta(1,1)-A1*G1';
P12 = eye(6)*delta(1,2)-A1*G2';
P13 = eye(6)*delta(1,3)-A1*G3';
P21 = eye(6)*delta(2,1)-A2*G1';
P22 = eye(6)*delta(2,2)-A2*G2';
P23 = eye(6)*delta(2,3)-A2*G3';
P31 = eye(6)*delta(3,1)-A3*G1';
P32 = eye(6)*delta(3,2)-A3*G2';
P33 = eye(6)*delta(3,3)-A3*G3';
P = [P11,P12,P13;
     P21,P22,P23;
     P31,P32,P33];
E = [Rr,zeros(3),zeros(3),zeros(3),zeros(3),zeros(3);
     zeros(3),Rr,zeros(3),zeros(3),zeros(3),zeros(3);
     zeros(3),zeros(3),Rr,zeros(3),zeros(3),zeros(3);
     zeros(3),zeros(3),zeros(3),Rr,zeros(3),zeros(3);
     zeros(3),zeros(3),zeros(3),zeros(3),Rr,zeros(3);
     zeros(3),zeros(3),zeros(3),zeros(3),zeros(3),Rr];
% ---------------------------------
% 计算EK、EF
EFg = E*P'*ef;
F1 = zeros(3,18);
F2 = zeros(3,18);
for i  = 1:6
    ni = ef(3*i-2:3*i);
    ni_skew = skew(ni);
    F2(1:3,3*i-2:3*i) = ni_skew';
    if i == 1
        F1(1:3,3*i-2:3*i) = ni_skew';
    elseif i == 3
        F1(1:3,3*i-2:3*i) = ni_skew';
    elseif i == 5
        F1(1:3,3*i-2:3*i) = ni_skew';
    end
end
F1 = F1';
F2 = F2';
EKg = E*(P'*ek*P-G*F1'*P-F2*G')*E';
%%
% 计算总体切线刚度阵
Psi1 = Rxy(1,:)';
psi1 = norm(Psi1);
if psi1 == 0
    Ts1 = eye(3);
else
e1 = Psi1/psi1;
Ts1 = sin(psi1)/psi1*eye(3)+(1-sin(psi1)/psi1)*e1*e1'+...
     0.5*(sin(0.5*psi1)/(0.5*psi1))^2*skew(Psi1);
end
Psi2 = Rxy(2,:)';
psi2 = norm(Psi2);
if psi2 == 0
    Ts2 = eye(3);
else
e2 = Psi2/psi2;
Ts2 = sin(psi2)/psi2*eye(3)+(1-sin(psi2)/psi2)*e2*e2'+...
     0.5*(sin(0.5*psi2)/(0.5*psi2))^2*skew(Psi2);
end
Psi3 = Rxy(3,:)';
psi3 = norm(Psi3);
if psi3 ==0
    Ts3 = eye(3);
else
e3 = Psi3/psi3;
Ts3 = sin(psi3)/psi3*eye(3)+(1-sin(psi3)/psi3)*e3*e3'+...
     0.5*(sin(0.5*psi3)/(0.5*psi3))^2*skew(Psi3);
end
% ---------------------------------
H1 = [eye(3),zeros(3);zeros(3),Ts1];
H2 = [eye(3),zeros(3);zeros(3),Ts2];
H3 = [eye(3),zeros(3);zeros(3),Ts3];
H = [H1,zeros(6),zeros(6);
     zeros(6),H2,zeros(6);
     zeros(6),zeros(6),H3];
EFg1 = EFg(1:6);
EFg2 = EFg(7:12);
EFg3 = EFg(13:18);
EF1 = H1'*EFg1;
EF2 = H2'*EFg2;
EF3 = H3'*EFg3;
EF_B = [EF1;EF2;EF3];
EF_cr = Te*eforcemG_iTR3(enc,Eepi,we,wk,wg,t)-EF_B;
% ------------------------------------
%计算Kh
M1 = EF1(4:6);
M2 = EF2(4:6);
M3 = EF3(4:6);
if psi1 == 0
    Kh1 = zeros(3);
else
Kh1 = (cos(psi1)-sin(psi1)/psi1)/psi1*(M1*e1'-(e1'*M1)*e1*e1')+...
      (1-sin(psi1)/psi1)/psi1*(e1*M1'-2*(e1'*M1)*e1*e1'+(e1'*M1)*eye(3))-...
      (sin(psi1)/psi1-(sin(0.5*psi1)/(0.5*psi1))^2)*cross(e1,M1)*e1'+...
      0.5*(sin(0.5*psi1)/(0.5*psi1))^2*skew(M1);
end
if psi2 == 0
    Kh2 = zeros(3);
else
Kh2 = (cos(psi2)-sin(psi2)/psi2)/psi2*(M2*e2'-(e2'*M2)*e2*e2')+...
      (1-sin(psi2)/psi2)/psi2*(e2*M2'-2*(e2'*M2)*e2*e2'+(e2'*M2)*eye(3))-...
      (sin(psi2)/psi2-(sin(0.5*psi2)/(0.5*psi2))^2)*cross(e2,M2)*e2'+...
      0.5*(sin(0.5*psi2)/(0.5*psi2))^2*skew(M2);
end
if psi3 == 0
    Kh3 = zeros(3);
else
Kh3 = (cos(psi3)-sin(psi3)/psi3)/psi3*(M3*e3'-(e3'*M3)*e3*e3')+...
      (1-sin(psi3)/psi3)/psi3*(e3*M3'-2*(e3'*M3)*e3*e3'+(e3'*M3)*eye(3))-...
      (sin(psi3)/psi3-(sin(0.5*psi3)/(0.5*psi3))^2)*cross(e3,M3)*e3'+...
      0.5*(sin(0.5*psi3)/(0.5*psi3))^2*skew(M3);
end
Kh = zeros(18);
Kh(4:6,4:6) = Kh1;
Kh(10:12,10:12) = Kh2;
Kh(16:18,16:18) = Kh3;
EK_cr = H'*EKg*H + Kh;
end